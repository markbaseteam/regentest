[[Participatory Design]] Summary: Engage stakeholders, users, and the local community in the design process, fostering a sense of ownership, collaboration, and shared decision-making.

Context: Applicable to projects that aim to create inclusive, user-centered designs that reflect the needs, aspirations, and values of the community.

Therefore: By embracing participatory design, the project ensures that diverse perspectives are considered, builds trust, and leads to more socially, culturally, and environmentally responsive outcomes.

Examples: Conducting workshops, focus groups, and design charrettes involving stakeholders, incorporating user feedback, and facilitating co-design processes.

Related Patterns: Community Engagement, Inclusive Design, Empowering Local Economies, Participatory Decision-making.

Questions: How can we engage stakeholders, users, and the local community in the design process, fostering a sense of ownership, collaboration, and shared decision-making? How can participatory design approaches contribute to creating inclusive, user-centered designs that reflect the needs, aspirations, and values of the community?