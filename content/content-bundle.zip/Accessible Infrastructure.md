[[Accessible Infrastructure]] Summary: Design infrastructure that is inclusive, providing equitable access to all individuals regardless of their physical abilities.

Context: Applicable to projects that involve the design of public facilities, transportation systems, and urban environments, aiming to create accessible and barrier-free spaces.

Therefore: By incorporating accessible infrastructure, the design ensures equal opportunities for individuals of diverse abilities to navigate and utilize the built environment independently.

Examples: Providing ramps, elevators, and tactile signage for individuals with mobility impairments, incorporating audio cues and visual indicators for individuals with sensory impairments, and designing inclusive seating and rest areas.

Related Patterns: [[Universal Design]], [[Sense of Belonging]], [[Social Equity]], [[Inclusive Design]].

Question: How can we design infrastructure that is inclusive, providing equitable access to all individuals regardless of their physical abilities?