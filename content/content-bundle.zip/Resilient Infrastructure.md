[[Resilient Infrastructure]] Summary: Design and develop infrastructure systems that are resilient to climate change impacts, natural hazards, and disruptive events.

Context: Applicable to projects that aim to enhance the resilience and adaptability of critical infrastructure and public services.

Therefore: By creating resilient infrastructure, the project reduces vulnerability, ensures continuity of essential services, and enhances community safety.

Examples: Implementing climate-responsive design, integrating green infrastructure in infrastructure planning, and considering adaptive strategies for infrastructure systems.

Related Patterns: Regenerative Water Management, Community Resilience, Sustainable Drainage Systems, Smart Grid Integration.

Questions: How can we design and develop infrastructure systems that are resilient to climate change impacts, natural hazards, and disruptive events? How can resilient infrastructure contribute to reducing vulnerability, ensuring continuity of essential services, and enhancing community safety?