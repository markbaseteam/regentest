[[Community Resilience]] Summary: Foster community resilience by designing buildings and neighborhoods that can withstand and adapt to various environmental, social, and economic challenges.

Context: Applicable to projects situated in areas prone to natural disasters, climate change impacts, or social vulnerabilities.

Therefore: By promoting community resilience, the design enhances the ability of individuals and communities to respond, recover, and thrive in the face of adversity.

Examples: Incorporating resilient building materials and construction techniques, designing flexible and adaptable spaces, integrating renewable energy and off-grid systems, and fostering community networks and collaboration.

Related Patterns: Adaptive Reintegration, Regenerative Water Management, Resilient Infrastructure, Social Equity.

Questions: How can we foster community resilience by designing buildings and neighborhoods that can withstand and adapt to various environmental, social, and economic challenges? How can the built environment contribute to community preparedness, response, and long-term resilience?