Summary: Design spaces and environments that foster a sense of connection, belonging, and community among individuals, promoting social interaction, well-being, and a shared sense of ownership.

Context: Applicable to various types of projects, particularly those aimed at creating inclusive communities and social gathering spaces.

Therefore: By prioritizing a sense of belonging, the design creates environments where individuals feel accepted, valued, and connected to their surroundings and the people around them.

Examples: Creating communal gathering spaces, incorporating seating areas that encourage interaction, designing welcoming entryways, and incorporating elements that reflect the local culture and context.

Related Patterns: Community Engagement, Place Identity, Social Equity, Inclusive Design.

Question: How can we design spaces that foster a sense of belonging and community, where individuals feel connected, valued, and a sense of ownership over their surroundings?