[[Bioclimatic Zoning]] Summary: Design spaces that respond to the local climate and microclimatic conditions, optimizing thermal comfort and energy efficiency through thoughtful zoning and orientation strategies.

Context: Applicable to projects in diverse climatic regions, aiming to create comfortable and sustainable environments by harnessing natural climatic resources.

Therefore: By employing bioclimatic zoning, the design maximizes the benefits of natural ventilation, solar heat gain, shading, and thermal mass, enhancing occupant comfort and reducing energy consumption.

Examples: Organizing spaces based on sun exposure and prevailing winds, incorporating shading devices and greenery for passive cooling, and optimizing building orientation for solar gain.

Related Patterns: [[Passive Solar Design]], [[Natural Ventilation]], [[Energy-Efficient Systems]], S[[ustainable Construction]].

Question: How can we design spaces that respond to the local climate and microclimatic conditions, optimizing thermal comfort and energy efficiency through thoughtful zoning and orientation strategies?