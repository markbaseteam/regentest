[[Affordable Housing Solutions]] Summary: Develop housing solutions that are affordable, accessible, and meet the needs of diverse communities, promoting social equity and housing security.

Context: Applicable to projects that address the challenges of affordable housing and strive to create inclusive and sustainable communities.

Therefore: By providing affordable housing solutions, the project supports social equity, reduces housing inequality, and enhances community well-being.

Examples: Designing mixed-income housing, co-housing models, and incorporating cost-effective construction methods and materials.

Related Patterns: [[Social Equity]], [[Inclusive Design]], [[Community Engagement]], [[Sustainable Construction]]

Questions: How can we develop housing solutions that are affordable, accessible, and meet the needs of diverse communities, promoting social equity and housing security? How can affordable housing solutions contribute to supporting social equity, reducing housing inequality, and enhancing community well-being?