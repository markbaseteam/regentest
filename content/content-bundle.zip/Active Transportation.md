[[Active Transportation]] Summary: Design and promote active transportation infrastructure to encourage walking, cycling, and other non-motorized modes of transportation, fostering healthier lifestyles and reducing carbon emissions.

Context: Applicable to urban areas, neighborhoods, and transportation planning, aiming to create walkable and bike-friendly communities.

Therefore: By prioritizing active transportation, the design promotes physical activity, reduces reliance on fossil fuels, and creates more livable and sustainable environments.

Examples: Designing safe pedestrian pathways, creating dedicated cycling lanes, integrating bike-sharing programs, and providing amenities such as bike racks and pedestrian-friendly amenities.

Related Patterns: [[Sustainable Transportation]], [[Accessible Public Spaces]], [[Community Resilience]], [[Efficient Resource Allocation]].

Question: How can we design our communities to prioritize active transportation, encouraging walking, cycling, and other non-motorized modes of transportation as a means to foster healthier lifestyles and reduce carbon emissions?