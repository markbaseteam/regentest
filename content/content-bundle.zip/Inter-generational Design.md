[[Inter-generational Design]] Summary: Design and create spaces that accommodate the needs and preferences of all generations, fostering social interaction, and a sense of community.

Context: Applicable to projects that aim to create inclusive and cohesive communities, bridging generational gaps, and promoting social integration.

Therefore: By incorporating inter-generational design principles, the project encourages social interaction, facilitates knowledge exchange, and enhances community cohesion.

Examples: Designing multipurpose spaces, inter-generational activity areas, and programs that promote inter-generational collaboration and interaction.

Related Patterns: Inclusive Design, Social Cohesion, Community Engagement, Sense of Belonging.

Questions: How can we design and create spaces that accommodate the needs and preferences of all generations, fostering social interaction and a sense of community? How can inter-generational design principles contribute to encouraging social interaction, facilitating knowledge exchange, and enhancing community cohesion?