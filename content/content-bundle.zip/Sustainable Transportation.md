[[Sustainable Transportation]] Summary: Promote sustainable transportation options and design infrastructures that prioritize walking, cycling, public transit, and other low-carbon modes of transportation.

Context: Applicable to projects that prioritize reducing reliance on private vehicles, enhancing mobility, and improving air quality.

Therefore: By supporting sustainable transportation, the project reduces greenhouse gas emissions, improves accessibility, and promotes healthier and more livable communities.

Examples: Designing pedestrian-friendly streets, incorporating bicycle lanes, enhancing public transit networks, and providing infrastructure for electric vehicles.

Related Patterns: Active Transportation, Accessible Public Spaces, Green Building Certifications, Smart Energy Management.

Questions: How can we promote sustainable transportation options and design infrastructures that prioritize walking, cycling, public transit, and other low-carbon modes of transportation? How can sustainable transportation contribute to reducing greenhouse gas emissions, improving accessibility, and promoting healthier and more livable communities?