[[Natural Daylighting]] Summary: Maximize the use of natural light to enhance visual comfort, reduce energy consumption, and promote a healthy indoor environment.

Context: Applicable to projects seeking to optimize natural lighting conditions, reduce reliance on artificial lighting, and enhance occupant well-being.

Therefore: By prioritizing natural daylighting, the project reduces energy consumption, improves visual comfort, and creates a healthier and more pleasant indoor environment.

Examples: Incorporating large windows, skylights, light shelves, and light-diffusing materials to maximize the entry of natural light into interior spaces.

Related Patterns: Energy-Efficient Systems, Healthy Indoor Environment, Biophilic Integration, Universal Design.

Questions: How can we maximize the use of natural light to enhance visual comfort, reduce energy consumption, and promote a healthy indoor environment? How can natural daylighting contribute to reducing energy consumption, improving visual comfort, and creating a healthier and more pleasant indoor environment?