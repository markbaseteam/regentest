[[Community Engagement]] Summary: Foster meaningful engagement and participation of the community throughout the design and decision-making process, ensuring their voices are heard, and their needs are considered.

Context: Relevant for projects that have a direct impact on the community, such as public spaces, community centers, or urban development initiatives.

Therefore: By fostering community engagement, the design process becomes more inclusive, reflective of local aspirations, and creates a sense of ownership and pride among community members.

Examples: Organizing community workshops and charrettes, conducting surveys and interviews to gather input, and establishing ongoing communication channels for collaboration and feedback.

Related Patterns: Participatory Design, Community Engagement and Co-creation, Social Equity, Empowering Local Economies.

Question: How can we meaningfully engage the community in the design and decision-making process to ensure that their perspectives, aspirations, and needs are integrated into the final design?