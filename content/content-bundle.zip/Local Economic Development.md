[[Local Economic Development]] Summary: Foster local economic growth, job creation, and community resilience by prioritizing local businesses, entrepreneurship, and investment in the project's vicinity.

Context: Applicable to projects that seek to support the local economy, create employment opportunities, and strengthen community ties.

Therefore: By prioritizing local economic development, the project contributes to the prosperity, resilience, and self-sufficiency of the surrounding community.

Examples: Engaging local suppliers and contractors, promoting local artisans and craftsmen, facilitating entrepreneurship and small business development.

Related Patterns: Empowering Local Economies, Community Resilience, Social Equity, Sustainable Construction.

Questions: How can we foster local economic growth, job creation, and community resilience by prioritizing local businesses, entrepreneurship, and investment in the project's vicinity? How can local economic development contribute to the prosperity, resilience, and self-sufficiency of the surrounding community?