[[Climate-Responsive Landscaping]] Summary: Design and plan landscapes that are responsive to local climate conditions, supporting biodiversity, water management, and ecological resilience.

Context: Applicable to projects that prioritize sustainable and climate-responsive design approaches for outdoor spaces.

Therefore: By incorporating climate-responsive landscaping, the project enhances ecosystem health, reduces water consumption, mitigates climate-related risks, and creates enjoyable and functional outdoor environments.

Examples: Selecting regionally appropriate plant species, incorporating green infrastructure, implementing water-efficient irrigation systems, and designing microclimates.

Related Patterns: Urban Biodiversity, Regenerative Water Management, Ecological Corridors, Bioclimatic Zoning.

Questions: How can we design and plan landscapes that are responsive to local climate conditions, supporting biodiversity, water management, and ecological resilience? How can climate-responsive landscaping contribute to ecosystem health, water conservation, climate adaptation, and the creation of enjoyable outdoor environments?