[[Ecological Connectivity]] Summary: Design and plan spaces that promote ecological connectivity and enhance biodiversity by creating linkages between natural habitats and supporting wildlife movement.

Context: Relevant for projects located in ecologically significant areas or areas where habitat fragmentation poses a challenge to wildlife movement and biodiversity conservation.

Therefore: By incorporating ecological connectivity, the design enhances habitat connectivity, enables species movement, and supports the overall health and resilience of the ecosystem.

Examples: Designing wildlife corridors and greenways that connect natural areas, incorporating green roofs and vertical gardens to provide habitat for birds and insects, or integrating native plantings that support local biodiversity.

Related Patterns: Urban Biodiversity, Ecological Corridors, Regenerative Water Management, Natural Landscaping.

Question: How can we design our spaces to promote ecological connectivity, supporting wildlife movement and fostering a harmonious relationship between human development and the natural environment?