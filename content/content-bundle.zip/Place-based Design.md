[[Place-based Design]] Summary: Embrace the unique characteristics, context, and identity of a place to create site-specific designs that respond to local culture, climate, geography, and community needs.

Context: Applicable to projects that prioritize a deep understanding of the site's context and aim to create designs that are deeply rooted in their specific location.

Therefore: By adopting a place-based design approach, the project fosters a strong sense of place, enhances environmental sustainability, and promotes a harmonious relationship between people and their surroundings.

Examples: Conducting thorough site analysis, integrating vernacular architecture and local materials, adapting to microclimate conditions, and engaging local stakeholders in the design process.

Related Patterns: Contextual Design, Sense of Belonging, Cultural Expression, Ecological Connectivity.

Questions: How can we embrace the unique characteristics, context, and identity of a place to create site-specific designs that respond to local culture, climate, geography, and community needs? How can place-based design contribute to environmental sustainability, a sense of belonging, and a harmonious relationship between people and their surroundings?