Summary: Emphasize the use of locally sourced materials, promoting sustainability, supporting local economies, and preserving the unique character of a place.

Context: Applicable to projects with a focus on sustainable and contextually responsive design, aiming to minimize the ecological footprint and promote local craftsmanship.

Therefore: By prioritizing local materials sourcing, the design reduces transportation impacts, supports local industries, and connects the built environment to its natural and cultural context.

Examples: Using locally harvested timber, stone, or earth-based materials, sourcing construction materials from nearby suppliers, and incorporating reclaimed or salvaged materials.

Related Patterns: Sustainable Construction, Low Embodied Energy, Circular Economy Integration, Place-based Design.

Question: How can we emphasize the use of locally sourced materials in our design, promoting sustainability, supporting local economies, and preserving the unique character of a place?