[[Sustainable Drainage Systems]] Summary: Design and integrate sustainable drainage systems that manage stormwater runoff, reduce flood risks, and promote water conservation.

Context: Applicable to projects in urban and suburban areas that aim to address stormwater management challenges and promote water-sensitive design.

Therefore: By implementing sustainable drainage systems, the project reduces flood risks, promotes groundwater recharge, and minimizes pollution from stormwater runoff.

Examples: Incorporating green roofs, rain gardens, permeable pavements, and bioswales to manage stormwater and encourage natural infiltration.

Related Patterns: Regenerative Water Management, Rainwater Harvesting, Permeable Surfaces, Ecological Corridors.

Questions: How can we design and integrate sustainable drainage systems that manage stormwater runoff, reduce flood risks, and promote water conservation? How can sustainable drainage systems contribute to reducing flood risks, promoting groundwater recharge, and minimizing pollution from stormwater runoff?