[[Urban Green Spaces]] Summary: Integrate green spaces, parks, and urban forests within the built environment to enhance biodiversity, improve air quality, and promote well-being.

Context: Applicable to projects within urban settings, aiming to counteract urbanization impacts and create healthier, more livable cities.

Therefore: By incorporating urban green spaces, the project enhances biodiversity, mitigates heat island effects, and improves the overall quality of urban life.

Examples: Creating pocket parks, rooftop gardens, vertical greenery, and urban farms to increase green coverage and promote a connection with nature.

Related Patterns: Biophilic Integration, Ecological Corridors, Sense of Belonging, Community Engagement.

Questions: How can we integrate green spaces, parks, and urban forests within the built environment to enhance biodiversity, improve air quality, and promote well-being? How can urban green spaces contribute to enhancing biodiversity, mitigating heat island effects, and improving the overall quality of urban life?