[[Community Engagement and Co-creation]] Summary: Foster meaningful engagement and collaboration with the community throughout the project development process to ensure their needs, aspirations, and values are incorporated.

Context: Applicable to projects that prioritize community involvement, co-creation, and a sense of shared ownership.

Therefore: By actively engaging the community and promoting co-creation, the project builds stronger relationships, enhances social cohesion, and increases the project's relevance and impact.

Examples: Hosting community workshops, charrettes, and design competitions, forming community partnerships and advisory groups, and involving the community in decision-making and implementation.

Related Patterns: Participatory Decision-making, Inclusive Design, Social Cohesion, Sense of Belonging.

Questions: How can we foster meaningful engagement and collaboration with the community throughout the project development process to ensure their needs, aspirations, and values are incorporated? How can community engagement and co-creation contribute to building stronger relationships, enhancing social cohesion, and increasing the project's relevance and impact?