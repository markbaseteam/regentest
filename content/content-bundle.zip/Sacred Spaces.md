[[Sacred Spaces]] Summary: Design and create sacred spaces that evoke a sense of spirituality, peace, and connection with the natural and built environment.

Context: Applicable to projects where the integration of spiritual and contemplative elements is desired, such as religious or meditative spaces.

Therefore: By incorporating sacred spaces, the design provides opportunities for introspection, reflection, and connection with the transcendent, fostering a sense of well-being and harmony.

Examples: Designing prayer rooms, meditation gardens, chapels, or spaces inspired by sacred geometries and natural elements.

Related Patterns: Place Identity, Sense of Belonging, Cultural Expression, Restorative Landscapes.

Questions: How can we design and create sacred spaces that evoke a sense of spirituality, peace, and connection with the natural and built environment? How can the integration of sacred spaces contribute to the well-being and harmony of individuals and communities?