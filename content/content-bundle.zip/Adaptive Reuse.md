**Pattern: Adaptive Reuse**

**Summary:** Adaptive reuse refers to the process of repurposing existing structures or buildings for new functions, preserving their historic and architectural value while promoting sustainability and minimizing environmental impact.

**Context:** Applicable to projects involving existing structures or buildings with significant heritage value, as well as those seeking to minimize resource consumption and reduce waste through creative reuse.

**Problem:** With the continuous development of new construction projects, many historic and architecturally valuable structures are at risk of demolition, leading to the loss of cultural heritage and contributing to waste generation.

**Therefore:** Adaptive reuse seeks to preserve the embodied energy and cultural significance of existing structures by transforming them into functional and sustainable spaces. By repurposing buildings, architects can reduce construction waste, conserve resources, and breathe new life into historical structures.

**Examples:** Converting old warehouses into loft apartments, transforming industrial buildings into creative workspaces, repurposing historic schools into community centers, renovating churches into cultural venues.

**Related Patterns:**

- [[Heritage Conservation]]
- [[Sustainable Construction]]
- [[Life Cycle Assessment]]
- [[Community Engagement]]

**Questions:** How can you creatively repurpose existing structures or buildings in your project to preserve their historic value and promote sustainability? What strategies can be employed to minimize waste, conserve resources, and ensure a seamless integration of old and new elements in the adaptive reuse process?