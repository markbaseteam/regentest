[[Walkability]] Summary: Design and create pedestrian-friendly environments that prioritize safe and convenient walking experiences, promoting human-scale connectivity and reducing reliance on motorized transportation.

Context: Applicable to projects in urban or mixed-use settings where promoting active transportation and reducing car dependency are key goals.

Therefore: By prioritizing walkability, the project enhances the quality of life, encourages physical activity, reduces traffic congestion, improves air quality, and fosters vibrant and inclusive communities.

Examples: Designing well-connected pedestrian pathways, providing ample sidewalk space, ensuring safe and well-lit walking environments, integrating amenities such as benches, public art, and green spaces along walking routes.

Related Patterns: [[Active Transportation]], [[Urban Green Spaces]], [[Accessible Public Spaces]], [[Community Engagement]].

Questions: How can we design and create pedestrian-friendly environments that prioritize safe and convenient walking experiences? How can promoting walkability enhance the quality of life, encourage physical activity, reduce traffic congestion, improve air quality, and foster vibrant and inclusive communities in our project?