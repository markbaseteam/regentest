[[Human-scale Design]] Summary: Create environments that prioritize the human experience, scale, and proportions, promoting comfort, accessibility, and a sense of intimacy.

Context: Applicable to various projects, particularly those focused on creating user-friendly and inclusive spaces that prioritize human needs and interaction.

Therefore: By emphasizing human-scale design, the project ensures that spaces are comfortable, navigable, and provide opportunities for social connection and interaction.

Examples: Designing pedestrian-friendly streetscapes, incorporating appropriate lighting and signage, and considering ergonomic principles in furniture and spatial layout.

Related Patterns: Universal Design, Accessible Infrastructure, Sense of Belonging, Inclusive Design.

Question: How can we prioritize the human experience, scale, and proportions in our design, creating comfortable and inclusive spaces that promote interaction and well-being?