[[Social Equity]] Summary: Design spaces and initiatives that address social disparities and promote equal access to resources, opportunities, and services, fostering a more just and inclusive society.

Context: Relevant for projects in diverse communities and areas with social and economic disparities, seeking to create more equitable and inclusive environments.

Therefore: By prioritizing social equity, the design aims to reduce inequalities, create opportunities for all individuals, and promote a sense of belonging and well-being.

Examples: Incorporating affordable housing options, providing community services and facilities, creating accessible public spaces, and implementing strategies for economic empowerment.

Related Patterns: Inclusive Design, Community Engagement, Empowering Local Economies, Affordable Housing Solutions.

Question: How can we design our spaces and initiatives to address social disparities, promote equal access to resources and opportunities, and create more equitable and inclusive communities?