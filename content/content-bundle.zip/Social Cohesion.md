[[Social Cohesion]] Summary: Foster social cohesion and a sense of community by designing spaces and environments that encourage interaction, collaboration, and inclusivity.

Context: Applicable to projects that aim to create social connections, strengthen community bonds, and promote social equity.

Therefore: By prioritizing social cohesion, the design creates inclusive and welcoming spaces that facilitate social interaction, promote diversity, and enhance the overall well-being of individuals and communities.

Examples: Designing communal gathering spaces, incorporating shared amenities, creating opportunities for collaborative activities, and promoting accessibility and inclusivity in the built environment.

Related Patterns: Community Engagement, Sense of Belonging, Inclusive Design, Social Equity.

Questions: How can we foster social cohesion and a sense of community by designing spaces and environments that encourage interaction, collaboration, and inclusivity? How can the built environment contribute to strengthening social connections,