[[Place Identity]] Summary: Design spaces that reflect and celebrate the unique cultural, historical, and social identity of a place, fostering a sense of pride, belonging, and attachment among its residents.

Context: Applicable to projects situated within communities with a strong sense of identity and cultural heritage, seeking to create spaces that resonate with the local context.

Therefore: By emphasizing place identity, the design helps preserve cultural heritage, strengthens community bonds, and creates a unique sense of place that is deeply valued by residents.

Examples: Incorporating local architectural styles and materials, integrating cultural symbols and motifs, and preserving or reinterpreting historical elements in the design.

Related Patterns: Cultural Expression, Heritage Conservation, Sense of Belonging, Participatory Design.

Question: How can we design our spaces to reflect and celebrate the unique identity and cultural heritage of a place, fostering a sense of pride, belonging, and attachment among its residents?