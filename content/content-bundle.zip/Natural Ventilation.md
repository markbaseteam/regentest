**Pattern: Natural Ventilation**

**Summary:** Natural ventilation is an architectural strategy that utilizes natural airflow and breezes to provide fresh air circulation and thermal comfort within a building, reducing the reliance on mechanical ventilation systems and improving energy efficiency.

**Context:** Applicable to projects located in regions with favorable climatic conditions for natural ventilation, where promoting indoor air quality and reducing energy consumption are important.

**Problem:** Conventional buildings often rely on mechanical ventilation systems that consume significant amounts of energy, contributing to greenhouse gas emissions and reducing the connection with natural elements and outdoor environments.

**Therefore:** Natural ventilation aims to maximize the use of natural airflow and breezes through careful building orientation, design of openings, and strategic placement of interior spaces. It promotes healthy indoor air quality, thermal comfort, and a sense of connection with the surrounding environment.

**Examples:** Incorporating operable windows to facilitate cross-ventilation, using building layout and site features to channel breezes, integrating stack effect principles for air movement, designing atriums or courtyards to facilitate air circulation.

**Related Patterns:**

- [[Passive Solar Design]]
- [[Bioclimatic Zoning]]
- [[Green Roofs]]
- [[Energy-Efficient Systems]]

**Questions:** How can you design your project to maximize natural ventilation and reduce the reliance on mechanical ventilation systems? What strategies can be employed to optimize airflow, enhance indoor air quality, and promote thermal comfort while maintaining energy efficiency?