[[Sense of Discovery]] Summary: Create spaces that evoke a sense of exploration, curiosity, and surprise, engaging users in a journey of discovery within the built environment.

Context: Applicable to projects that aim to provide unique and memorable experiences, encourage exploration, and create moments of delight.

Therefore: By incorporating elements of discovery, the project enhances user engagement, fosters a sense of wonder, and creates an emotional connection with the space.

Examples: Designing hidden paths, unexpected vistas, interactive installations, and art installations that reveal themselves gradually.

Related Patterns: Sense of Belonging, Place Identity, Storytelling Elements, Public Art Integration.

Questions: How can we create spaces that evoke a sense of exploration, curiosity, and surprise, engaging users in a journey of discovery within the built environment? How can elements of discovery contribute to enhancing user engagement, fostering a sense of wonder, and creating an emotional connection with the space?