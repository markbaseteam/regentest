[[Heritage Conservation]] Summary: Preserve and celebrate the historic, cultural, and architectural heritage of a place through sensitive restoration, adaptive reuse, and heritage conservation practices.

Context: Applicable to projects located in areas with significant heritage value or projects that aim to protect and enhance the historical fabric of a place.

Therefore: By prioritizing heritage conservation, the project safeguards the collective memory, maintains a sense of continuity, and promotes sustainable development rooted in the past.

Examples: Restoring historic buildings, repurposing heritage sites, incorporating traditional architectural elements, and engaging in community-led preservation efforts.

Related Patterns: Adaptive Reuse, Place Identity, Sense of Belonging, Contextual Design.

Questions: How can we preserve and celebrate the historic, cultural, and architectural heritage of a place through sensitive restoration, adaptive reuse, and heritage conservation practices? How can heritage conservation contribute to a sense of identity, continuity, and sustainable development?