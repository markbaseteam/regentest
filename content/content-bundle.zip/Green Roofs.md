**Pattern: Green Roofs**

**Summary:** Green roofs are vegetated roof systems that provide numerous environmental benefits, including improved stormwater management, enhanced thermal performance, and increased biodiversity while promoting aesthetic appeal and human well-being.

**Context:** Applicable to projects in urban areas or areas with limited green space, where optimizing stormwater management, reducing the heat island effect, and enhancing the ecological value of the built environment are desired.

**Problem:** Conventional roofs contribute to stormwater runoff, heat island effect, and lack of green space in urban areas. They also isolate occupants from nature, limiting opportunities for biophilic experiences and ecosystem support.

**Therefore:** Green roofs involve the installation of vegetation on the roof surface, providing natural insulation, reducing stormwater runoff, and improving air quality. They create urban green spaces, enhance biodiversity, and offer opportunities for recreation and connection with nature.

**Examples:** Extensive green roofs with low-maintenance plantings, intensive green roofs with diverse plant species and recreational spaces, rooftop gardens for food production, green roof systems that incorporate rainwater harvesting and irrigation.

**Related Patterns:**

- [[Biophilic Integration]]
- [[Regenerative Water Management]]
- [[Urban Biodiversity]]
- [[Natural Daylighting]]

**Questions:** How can you incorporate green roofs into your project to enhance stormwater management, reduce the heat island effect, and promote biodiversity? How can green roofs be designed to provide opportunities for recreation, improve air quality, and foster a sense of connection with nature?