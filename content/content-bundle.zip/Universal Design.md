[[Universal Design]] Summary: Design spaces that are accessible and inclusive for people of all ages, abilities, and backgrounds, promoting equal access, independence, and dignity.

Context: Applicable to all types of buildings and spaces, with a particular focus on public and shared spaces that should be welcoming and accessible to everyone.

Therefore: By incorporating universal design principles, the design ensures equal opportunities and access for all individuals, regardless of their physical or cognitive abilities.

Examples: Providing barrier-free entrances, installing accessible ramps and elevators, incorporating adjustable-height fixtures and furniture, and designing intuitive wayfinding systems.

Related Patterns: Inclusive Design, Accessible Infrastructure, Sense of Belonging, Empowering Local Economies.

Question: How can we integrate universal design principles into our spaces to create inclusive environments that promote equal access, independence, and dignity for people of all ages and abilities?