**Pattern: Passive Solar Design**

**Summary:** Passive solar design is an architectural approach that maximizes the use of solar energy for heating, cooling, and lighting by leveraging the building's orientation, layout, materials, and natural elements to optimize thermal comfort and reduce energy consumption.

**Context:** Applicable to projects in regions with abundant sunlight, where harnessing solar energy for heating and lighting is viable, and where reducing reliance on mechanical heating and cooling systems is desired.

**Problem:** Traditional buildings often rely heavily on mechanical systems for heating, cooling, and lighting, resulting in high energy consumption, increased greenhouse gas emissions, and dependency on non-renewable energy sources.

**Therefore:** Passive solar design seeks to utilize the building's site, orientation, and materials to optimize natural heating, cooling, and lighting. It involves strategic placement of windows, shading devices, thermal mass, and insulation to enhance energy efficiency and thermal comfort.

**Examples:** Designing buildings with south-facing windows to maximize solar gain in winter, using shading elements to prevent overheating in summer, incorporating thermal mass materials like concrete or adobe for heat storage, employing natural ventilation strategies.

**Related Patterns:**

- [[Bioclimatic Zoning]]
- [[Natural Ventilation]]
- [[Green Roofs]]
- [[Energy-Efficient Systems]]

**Questions:** How can you maximize the use of solar energy in your project to achieve heating, cooling, and lighting goals? What design strategies can be implemented to optimize the building's orientation, placement of windows, and use of shading devices for passive solar gain and effective energy management?