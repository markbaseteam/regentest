[[Indigenous Design Principles]] Summary: Incorporate indigenous knowledge, traditions, and design principles into the architectural and urban design process to honor and respect local cultures, ecosystems, and ways of life.

Context: Applicable to projects situated in areas with indigenous communities or projects that aim to integrate indigenous perspectives and values.

Therefore: By incorporating indigenous design principles, the project acknowledges the rich cultural heritage, promotes cultural sustainability, and fosters a harmonious relationship between people and the environment.

Examples: Integrating traditional building techniques, materials, and symbols, incorporating storytelling elements, and engaging in meaningful collaboration and consultation with indigenous communities.

Related Patterns: Cultural Expression, Place Identity, Community Engagement, Indigenous Wisdom.

Questions: How can we incorporate indigenous knowledge, traditions, and design principles into the architectural and urban design process to honor and respect local cultures, ecosystems, and ways of life? How can indigenous design principles contribute to cultural sustainability, community empowerment, and environmental stewardship?