[[Active Building Design]] Summary: Design buildings that promote physical activity, health, and well-being by incorporating features that encourage active lifestyles.

Context: Applicable to projects that prioritize human health, well-being, and the promotion of physical activity.

Therefore: By embracing active building design, the project supports a healthier population, increases productivity, and reduces healthcare costs.

Examples: Incorporating staircases, bike storage facilities, fitness spaces, and walking paths within the building design.

Related Patterns: [[Healthy Indoor Environment]], [[Walkability]], [[Biophilic Design]], [[Accessible Public Spaces]].

Questions: How can we design buildings that promote physical activity, health, and well-being by incorporating features that encourage active lifestyles? How can active building design contribute to supporting a healthier population, increasing productivity, and reducing healthcare costs?