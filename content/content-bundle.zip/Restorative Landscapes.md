[[Restorative Landscapes]] Summary: Create landscapes that promote healing, well-being, and ecological restoration, reconnecting people with nature and enhancing ecosystem functionality.

Context: Applicable to projects that prioritize the creation of outdoor spaces that offer therapeutic benefits, habitat restoration, and biodiversity enhancement.

Therefore: By designing restorative landscapes, the project provides opportunities for relaxation, rejuvenation, and ecological revitalization, fostering a sense of connection with the natural world.

Examples: Designing healing gardens, regenerative landscapes, urban parks, and green corridors that promote biodiversity and ecological balance.

Related Patterns: Urban Biodiversity, Ecological Corridors, Biophilic Integration, Community Resilience.

Questions: How can we create landscapes that promote healing, well-being, and ecological restoration, reconnecting people with nature and enhancing ecosystem functionality? How can restorative landscapes contribute to the physical, mental, and emotional well-being of individuals and communities?